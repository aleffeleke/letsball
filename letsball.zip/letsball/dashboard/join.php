<?php
if(isset($_GET['groupname'])){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "letsballdbh";
    $groupaddress = $_GET['groupaddress'];
    $groupname = $_GET['groupname'];
    $useremail = $_GET['useremail'];
    $grouptime = $_GET['grouptime'];
    $groupdescription = $_GET['groupdescription'];
    $groupdate = $_GET['groupdate'];
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
  
    $sql = "INSERT INTO usergroups (groupname, groupaddress,grouptime,groupdescription,groupdate,useremail)
    VALUES ('$groupname', '$groupaddress', '$grouptime' , '$groupdescription' , '$groupdate','$useremail');";
    
    
    if ($conn->query($sql) === TRUE) {
        header("Location:yourgroup.php?success");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();


}

?>