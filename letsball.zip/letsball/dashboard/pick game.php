<?php $active = 'pick game'; ?>
    <?php include 'includes/header.inc.php'; ?>
    <div class='main-content-inner'>
                <div class='container'>
    
                    <br>
                    <br>
                    <center>
                <div class='col-md-8' style='text-align:left; padding-left:20px; '>
                
                <div class='card'>
                  <div class='card' style='background:url(https://live.staticflickr.com/8094/8590935046_069be75293_b.jpg); padding:0px; padding-bottom:10px; background-size:cover;'>
        <div class='card-body pb-0' style='background-color:rgba(0,0,0,0.4); text-align:left;'>
                   <h3 style='color:white;'> pick game </h3>
                   <br>
                   <h3 style='color:white;'> 230 redfdhd road</h3>
                   <br>
                   <h3 style='color:white;'> 3:00pm </h3>
                   <br>
                    
                </div>
                
    
    
              </div>
                </div>
            </div>
            <br>
            <div  class='col-md-8' style='text-align:left;'>
            <h4>Description</h4>
                <p>dgwdkjgwdkjwdjkgwd</p>

                <a href='join.php?groupname=pick game&groupaddress=230 redfdhd road&grouptime=3:00pm&groupdescription=dgwdkjgwdkjwdjkgwd&useremail=stilixweb@gmail.com&groupdate=12/23/2222'><input type='submit' name='submit' class='form-control' id='submitbtn' style='  background:linear-gradient(58deg, rgba(220,32,82,1) 35%, rgba(243,60,106,1) 100%);  font-size:15px; border:0px; color:white;' value='Join'></a>
            </div>
            </center>
    
    </div>
    </div>
                
    </div>        
    </div>
    <?php include 'includes/footer.inc.php'; ?>
    </body>  
    </html>
    