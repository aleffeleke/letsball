<?php $active = "Dashboard"; ?>
<?php include "includes/header.inc.php"; ?>
<div class="main-content-inner">
<?php include "includes/dashboard_contents.inc.php"; ?>
</div>
</div>
            
</div>        
</div>
<?php include "includes/footer.inc.php"; ?>
</body>  
</html>
