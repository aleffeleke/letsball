$(document).ready(function () {
    $("#response").hide();
    $("#search").keyup(function () {
        var query = $("#search").val();
      
        if (query.length > 0) {
            $.ajax(
                {
     
                    url: 'index.php',
                    method: 'POST',
                    data: {
                        search: 1,
                        q: query
                    },
                    success: function (data) {
                        $("#response").show();
                        $("#response").html(data);
                    },
                    dataType: 'text'
                }
            );
        }
    });
    $(".main-content-inner").mouseover(function(){
        $("#response").hide();
    });
    $(document).on('click', 'li', function () {
        var country = $(this).text();
        $("#search").val(country);
        $("#response").html("");
    });
});