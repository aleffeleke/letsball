const firstpass = document.querySelector('#password');
const mymsg = document.querySelector('.msg');
const submitbtn = document.getElementById("submitbtn");

function myFunction() {
    if (firstpass.type === "password") {
        firstpass.type = "text";
    } else {
        firstpass.type = "password";
    }
}

firstpass.addEventListener("keydown", function () {
    if (firstpass.value.length < 7) {
        mymsg.innerHTML = "<img src='assets/images/cancel.png' width='25px'style='padding:5px; margin-bottom:5px;'> Password must be 8 or more characters ";
        mymsg.style.color = 'red';
        submitbtn.style.display = "none";
        submitbtn.disabled = true;
    }
    else {
        mymsg.innerHTML = "<img src='assets/images/checkmark.png'  width='25px'style='padding:5px; margin-bottom:5px;'> Good password";
        mymsg.style.color = 'green';
        submitbtn.style.display = "block";
        submitbtn.disabled = false;
    }


    if (firstpass.value.length == 0) {
        mymsg.innerText = " ";
    }
});
