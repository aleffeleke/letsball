<?php $active = 'Start a group'; ?>
<?php include 'includes/header.inc.php'; ?>
<div class='main-content-inner'>
            <div class='container'>

                <br>
                <br>
                <center>
            <div class='col-md-8' style='text-align:left; padding-left:20px; '>
            
            <div class='card'>
              <div class='card' style='background:url(https://live.staticflickr.com/8094/8590935046_069be75293_b.jpg); padding:0px; padding-bottom:10px; background-size:cover;'>
    <div class='card-body pb-0' style='background-color:rgba(0,0,0,0.4); text-align:left;'>
               <h3 style='color:white;'> This is just the test title </h3>
               <br>
               <h3 style='color:white;'> address </h3>
               <br>
               <h3 style='color:white;'> Time </h3>
               <br>
                
            </div>
            


          </div>
            </div>
        </div>
        <br>
        <div  class='col-md-8' style='text-align:left;'>
        <h4>Description</h4>
            <p>.khekfhejfhekfefefef </p>
            <input type='submit' name='submit' class='form-control' id='submitbtn' style='  background:linear-gradient(58deg, rgba(220,32,82,1) 35%, rgba(243,60,106,1) 100%);  font-size:15px; border:0px; color:white;' value='Join'>
        </div>
        </center>

</div>
</div>
            
</div>        
</div>
<?php include 'includes/footer.inc.php'; ?>
</body>  
</html>
