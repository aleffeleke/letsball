<?php $active = 'Come lets play ball'; ?>
    <?php include 'includes/header.inc.php'; ?>
    <div class='main-content-inner'>
                <div class='container'>
    
                    <br>
                    <br>
                    <center>
                <div class='col-md-8' style='text-align:left; padding-left:20px; '>
                
                <div class='card'>
                  <div class='card' style='background:url(https://live.staticflickr.com/8094/8590935046_069be75293_b.jpg); padding:0px; padding-bottom:10px; background-size:cover;'>
        <div class='card-body pb-0' style='background-color:rgba(0,0,0,0.4); text-align:left;'>
                   <h3 style='color:white;'> Come lets play ball </h3>
                   <br>
                   <h3 style='color:white;'> 160 agency road</h3>
                   <br>
                   <h3 style='color:white;'> 2:50pm </h3>
                   <br>
                    
                </div>
                
    
    
              </div>
                </div>
            </div>
            <br>
            <div  class='col-md-8' style='text-align:left;'>
            <h4>Description</h4>
                <p>We need five people</p>

                <a href='join.php?groupname=Come lets play ball&groupaddress=160 agency road&grouptime=2:50pm&groupdescription=We need five people&useremail=stilixweb@gmail.com&groupdate=08/23/2001'><input type='submit' name='submit' class='form-control' id='submitbtn' style='  background:linear-gradient(58deg, rgba(220,32,82,1) 35%, rgba(243,60,106,1) 100%);  font-size:15px; border:0px; color:white;' value='Join'></a>
            </div>
            </center>
    
    </div>
    </div>
                
    </div>        
    </div>
    <?php include 'includes/footer.inc.php'; ?>
    </body>  
    </html>
    