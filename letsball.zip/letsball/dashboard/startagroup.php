<?php $active = "Start a group"; ?>
<?php include "includes/header.inc.php"; ?>
<div class="main-content-inner">
<?php include "includes/account_contents.inc.php"; ?>
</div>
</div>
            
</div>        
</div>
<?php include "includes/footer.inc.php"; ?>
</body>  
</html>
