<?php

class Course extends Db_object  {
    protected static $dbh_table = "courses";
    protected static $db_table_fields = array('title','description','price','images','videolink');
    

    public $description;
    public $title;
    public $price;
    public $id;
    public $images;
    public $videolink;


    public static function search_courses($search){
        global $database;
        $search = $database->escape_string($search);
        $search = htmlspecialchars($search);
        $search = trim($search);
        return  Self::find_by_query("SELECT * FROM  " . Self::$dbh_table .  " WHERE `title` LIKE '%".$search."%' OR `description` LIKE '%".$search."%' ");
    }
    public static function find_all_course($limit = 3){
        global $database;
        return  Self::find_by_query("SELECT * FROM " . Self::$dbh_table .  " ORDER BY id DESC LIMIT $limit");
    }
    public static function find_course_by_title($title){
        global $database;
        return Self::find_by_query("SELECT * FROM " . Self::$dbh_table .  " WHERE title = '$title' ");
    }
    public static function find_course_by_id($id){
        global $database;
        $the_result_array =  Self::find_by_query("SELECT * FROM " . Self::$dbh_table .  " WHERE id = '$id' ");
        return !empty($the_result_array) ? array_shift($the_result_array) : false;
    }

    public  function add_course($file){
        $errors= array();
        $this->filename = $file['name'];
        $this->tmp_path = $file['tmp_name'];
        $this->type = $file['type'];
        $this->size = $file['size'];
      
   


   $file_ext = explode('.', $_FILES['image']['name']);
   $file_ext = end($file_ext);
   $extensions= array("jpeg","jpg","png","jfif");

   $target_path = "../dashboard/images/".$this->filename;


   if(in_array($file_ext,$extensions) === false){
      $errors[]="extension not allowed, please choose a JPEG or PNG file.";
   }
        if($this->size > 2097152){
           $errors[]='File size must be excately 2 MB';
        }
        if(empty($errors)==true){
            move_uploaded_file($this->tmp_path,$target_path);
            $this->images = $this->filename;
            $this->create();
            return true;
         }else{
            print_r($errors);
         }
    }

}
$course = new Course;

?>