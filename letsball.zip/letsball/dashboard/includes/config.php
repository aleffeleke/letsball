<?php

// Database connction constants

// define('DB_HOST','mysql.eagleseyefx.com');
// define('DB_USER','eagleseyefx');
// define('DB_PASS','Beasting-2019');
// define('DB_NAME','eagleseyefx_database');

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','eagleseye');

?>

