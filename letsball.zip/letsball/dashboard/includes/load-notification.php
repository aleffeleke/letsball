<?php
 require_once("init.php");

$notfication = notification::find_notification();

if(empty($notfication)){
 echo "no notfication";
}
else{
    foreach ($notfication as $notfication){
        echo '<div class="table-responsive">
        <table class="table table-hover progress-table text-center" >

            <tbody>

                <tr>
                <td>
                <img class="avatar user-thumb" src="assets/images/author/avatar.png" width="60px;" alt="avatar">admin@eagleseyefx.com
                    </td>
                    <td width="50%">'.$notfication->message.'</td>

                    <td>
                    '.$notfication->time.'
                    </td>

                </tr>';
    }
}
?>