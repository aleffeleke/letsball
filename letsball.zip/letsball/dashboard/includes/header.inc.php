<?php   
// require_once("includes/init.php"); 
?>
<?php 
// isset($_SESSION['email']) === true ? $_SESSION['email'] : redirect('login.php');
// if(isset($_POST['search'])) {
//     // $connection = new mysqli('localhost', 'root', '', 'eagleseye');
//     $connection = new mysqli('mysql.eagleseyefx.com', 'eagleseyefx', 'Beasting-2019', 'eagleseyefx_database');
//     $q = $connection->real_escape_string($_POST['q']);

//     $sql = $connection->query("SELECT * FROM  courses WHERE `title` LIKE '%".$q."%' OR `description` LIKE '%".$q."%'");
//     $response = "<ul>";
//     if ($sql->num_rows > 0) {
//         $response = "<ul>";

//         while ($data = $sql->fetch_array())
//             $response .= "<li>" . $data['title'] . "</li>";

//         $response .= "</ul>";
//     }else{
//         $response = "<ul>No data found</ul>";
//     }


//   exit($response);
// }
?>
        <?php
        $useremail ="stilixweb@gmail.com";
                $full = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                if(strpos($full , "errorid=") == true){
                    redirect("payment.php");
                }
                    ?>
<!doctype html>
 <html class="no-js" lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> <?php echo $active; ?> | Eagle's Eye FX</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="shortcut icon" href="assets/images/author/avatar.png">
    <link rel="stylesheet" href="assets/css/payment.css">
    <script src="assets/js/checker.js"></script>
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

   <style>
      body, html { width: 100%; height: 100%; }

        .dash-course-btn{
            padding:10px; 
            padding-left:20px; 
            padding-right:20px; 
            border:0px; 
            border-radius:1px; 
            background:#e9b84e; 
            color:white;
            margin:5px;
        }
        iframe{
            width:100%;
            margin-top:30px;
            border:0px;
            height:620px;
        }

    </style>
    </head>

    <body class="body-bg">
    <div id="preloader">
        <div class="loader"></div>
    </div>
      <div class="horizontal-main-wrapper">
        <!-- main header area start -->
        <div class="mainheader-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-3">
                        <div class="logo">
                            <img class="avatar user-thumb" src="assets/images/author/avatar.png" width="30px;" alt="avatar">
                        </div>
                    </div>
                    <!-- profile info & task notification -->
                    <div class="col-md-9 clearfix text-right">
                        <div class="clearfix d-md-inline-block d-block">
                            <div class="user-profile m-0">
                                <img class="avatar user-thumb" src="assets/images/author/user.png" alt="user" >
                                <h4 class="user-name dropdown-toggle" data-toggle="dropdown">        <?php  ?><i class="fa fa-angle-down"></i></h4>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="account.php">Account</a>
                                    <a class="dropdown-item" href="contact.php">Contact/Support</a>
                                    <a class="dropdown-item" href="logout.php">Log Out</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main header area end -->
        <!-- header area start -->
        <div class="header-area header-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-9  d-none d-lg-block">
                        <div class="horizontal-menu">
                        <nav>
                <ul id="nav_menu">
                <?php
                   if( $active == "Dashboard"){
                          echo "<li class='active'>";
                  }
                  else{
                    echo "<li>";
                  }
                            ?>
                          <a href='index.php' aria-expanded='true'><i class='ti-list'></i><span>Explore</span></a>

                   <?php
                   if( $active == "My Courses"){
                          echo "<li class='active'>";
                  }
                  else{
                    echo "<li>";
                  }
                            ?>
                          <a href='startagroup.php' aria-expanded='true'><i class='ti-user'></i><span>Start a new group</span></a>

                      </li>
                      <?php
                   if( $active == "Your groups"){
                          echo "<li class='active'>";
                  }
                  else{
                    echo "<li>";
                  }
                            ?>
                          <a href='yourgroup.php' aria-expanded='true'><i class='ti-user'></i><span>Your groups</span></a>

                      </li>
                      <?php
                      if($active == "Live Class"){
                                  echo "<li class='active'>";
                          }
                          else{
                            echo "<li>";
                          }
                                    ?>
                                    <a href='livetrade.php' aria-expanded='true'><i class='ti-email'></i><span>Messages</span></a>
                    </li>
      
                    </li>
                    <?php
                    if($active == "Notification"){
                                echo "<li class='active'>";
                        }
                        else{
                          echo "<li>";
                        }
                        ?>
                        <a href="notification.php" aria-expanded="true"><i class="ti-bell"></i><span>Notification</span></a>

                    </li>
                
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!-- nav and search button -->
                    <!-- mobile_menu -->
                    <div class="col-12 d-block d-lg-none">
                        <div id="mobile_menu"></div>
                    </div>
                </div>
            </div>
        </div>
