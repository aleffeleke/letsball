</table>
                                </td>
                            </tr>
    
                            <!-- END MAIN CONTENT AREA -->
                        </table>
    
                        <!-- START FOOTER -->
                        <div class="footer" style="clear: both; Margin-top: 10px; text-align: center; width: 100%;">
                            <table border="0" cellpadding="0" cellspacing="0"
                                style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
                                <tr>
                                    <td class="content-block"
                                        style="font-family: sans-serif; vertical-align: top; padding-bottom: 10px; padding-top: 10px; font-size: 12px; color: #999999; text-align: center;">
                                        <span class="apple-link"
                                            style="color: #999999; font-size: 12px; text-align: center;">Copyright ©
                                            <script type="text/javascript">
                                                document.write(new Date().getFullYear());
                                            </script> Eagleseyefx.com</span>
    
                                    </td>
                                </tr>
                                <tr>
                                    <td class="content-block powered-by"
                                        style="font-family: sans-serif; vertical-align: top; padding-bottom: 10px; padding-top: 10px; font-size: 12px; color: #999999; text-align: center;">
                                        Powered by <a href="http://stilixweb.com"
                                            style="color: #999999; font-size: 12px; text-align: center; text-decoration: none;">Stilixweb</a>.
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <!-- END FOOTER -->
    
                        <!-- END CENTERED WHITE CONTAINER -->
                    </div>
                </td>
                <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">&nbsp;</td>
            </tr>
        </table>
    </body>
    
    </html>