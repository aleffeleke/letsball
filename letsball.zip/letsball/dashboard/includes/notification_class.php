<?php

class notification extends Db_object  {
    protected static $dbh_table = "notification";
    protected static $db_table_fields = array('id','message');
    

    public $id;
    public $message;
    public $time;

    public static function find_notification_by_id($id){
        global $database;
        $the_result_array =  Self::find_by_query("SELECT * FROM notification WHERE id = '$id' ");
        return !empty($the_result_array) ? array_shift($the_result_array) : false;
    }
    public static function find_notification(){
        global $database;
        return  Self::find_by_query("SELECT * FROM notification");
    }
}
$notification  = new notification;

?>