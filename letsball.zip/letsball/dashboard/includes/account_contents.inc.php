<?php
if(isset($_POST['submit'])){
  $groupaddress = $_POST['groupaddress'];
  $groupname = $_POST['groupname'];
  $grouptime = $_POST['grouptime'];
  $groupdescription = $_POST['groupdescription'];
  $groupdate = $_POST['groupdate'];
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "letsballdbh";
  $useremail = "stilixweb@gmail.com";
  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  
  $sql = "INSERT INTO groups (groupname, groupaddress,grouptime,groupdescription,groupdate,groupurl)
  VALUES ('$groupname', '$groupaddress', '$grouptime' , '$groupdescription' , '$groupdate','$groupname.php');";
  
  if ($conn->multi_query($sql) === TRUE) {
    $file = fopen("$groupname.php","w");
    echo fwrite($file,"<?php" . ' $active' ." = '$groupname'; ?>
    <?php include 'includes/header.inc.php'; ?>
    <div class='main-content-inner'>
                <div class='container'>
    
                    <br>
                    <br>
                    <center>
                <div class='col-md-8' style='text-align:left; padding-left:20px; '>
                
                <div class='card'>
                  <div class='card' style='background:url(https://live.staticflickr.com/8094/8590935046_069be75293_b.jpg); padding:0px; padding-bottom:10px; background-size:cover;'>
        <div class='card-body pb-0' style='background-color:rgba(0,0,0,0.4); text-align:left;'>
                   <h3 style='color:white;'> $groupname </h3>
                   <br>
                   <h3 style='color:white;'> $groupaddress</h3>
                   <br>
                   <h3 style='color:white;'> $grouptime </h3>
                   <br>
                    
                </div>
                
    
    
              </div>
                </div>
            </div>
            <br>
            <div  class='col-md-8' style='text-align:left;'>
            <h4>Description</h4>
                <p>$groupdescription</p>

                <a href='join.php?groupname=$groupname&groupaddress=$groupaddress&grouptime=$grouptime&groupdescription=$groupdescription&useremail=$useremail&groupdate=$groupdate'><input type='submit' name='submit' class='form-control' id='submitbtn' style='  background:linear-gradient(58deg, rgba(220,32,82,1) 35%, rgba(243,60,106,1) 100%);  font-size:15px; border:0px; color:white;' value='Join'></a>
            </div>
            </center>
    
    </div>
    </div>
                
    </div>        
    </div>
    <?php include 'includes/footer.inc.php'; ?>
    </body>  
    </html>
    ");
    fclose($file);
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();
}

?>
<div class="main-content-inner">
            <div class="container" >

                <br>
                <br>
                <h5>Create a new group</h5>
                <br>
            
            <div class="col-md-8">
            
            <div class="card">
            <?php
               $full = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
              if(strpos($full , "update=sucess") == true){echo "<div style='width:50%;  color:green; padding:21px; text-align:left;  font-size:15px;'>Your changes have been successfully saved.</div>";}
              elseif(strpos($full , "update=error") == true){ echo "<div style='width:50%;  color:red; padding:21px; text-align:left;  font-size:15px;'>Could not update</div>";}
			        ?>
              <div class="card-body">

                <form method="post" action=" ">
                  <div class="row">
                   <div class="col-md-6 pr-1">

                      <div class="form-group">
                        <label>Group event address</label>
                        <input type="text" class="form-control"  required style="text-transform:capitalize;" placeholder=" "   name="groupaddress">
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>Group name</label>
                    <input type="text" required class="form-control" style="text-transform:capitalize;" placeholder=""   name="groupname">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Event time <i>e.g 2:00PM or AM</i></label>
                        <input type="text" class="form-control" style="text-transform:capitalize;" name="grouptime"   placeholder=" "   >
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>Date <i>e.g mm/dd/yyyy</i></label>
                    <input type="text" required class="form-control" style="text-transform:capitalize;" placeholder=" "   name="groupdate">
                      </div>
                    </div>
                  </div>
              </div>
            </div>
            <div class="card">
              <div class="card-body">
                <h6>Event description </h6>
                <br>
                <div class="row">
                
                  
                  </div>
                  <div class="row mb-4 rmber-area">
                            <div class="col-6">
                            <textarea rows="15" cols="120" name="groupdescription"></textarea>
                            </div>
                        </div>
                        <p class="msg"></p>
                  <div class="row">
                    <div class="col-md-4 pr-1">
                      <div class="form-group">
                        <br>
                        <input type="submit" name="submit" class="form-control" id="submitbtn" style="  background:linear-gradient(58deg, rgba(220,32,82,1) 35%, rgba(243,60,106,1) 100%);  font-size:15px; border:0px; color:white;" value="Create">
                      </div>
                    </div>


                  </div>

                </form>
              </div>
            </div>
          </div>
             
            </div>
        </div>
