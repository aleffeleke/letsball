<?php
require_once "config.php";

class Database {
    public $connection;

    public function __construct(){

       $this->connection = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
                
        if($this->connection->connect_errno){
            die("database  Connection Failed". $this->connection->connect_error);
        }

    }

    public function query($sql){
     $result = $this->connection->query($sql);
     $this->confirm_query($result);
     return $result;
     
    }


    public function confirm_query($result){
      if(!$result){
        die("Query Failed". $this->connection->connect_error);
      }
    }
    
    public function escape_string($string){
      $escape_string = $this->connection->real_escape_string($string);
      return $escape_string;
    }
    
   public function the_insert_id(){
    return $this->connection->insert_id;
    }
    
     }

$database = new Database;



?>