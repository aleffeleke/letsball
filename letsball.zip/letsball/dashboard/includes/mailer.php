<?php

class Mail{
    public function mail(){
      
      use PHPMailer\PHPMailer\PHPMailer;
      use PHPMailer\PHPMailer\Exception;

  }
}

?>