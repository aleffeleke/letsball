<?php

  Class Adminuser  extends Db_object  {
    protected static $dbh_table = "adminlogin";
    protected static $db_table_fields = array('id','email','password');
    

    public $id;
    public $email;
    public $password;



  }
  $Adminuser = new Adminuser;

  
?>