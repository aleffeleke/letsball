<?php
session_start();
require_once('function.php');
require_once('mailconfig.php');
require_once("db_object.php");
require_once("config.php");
require_once("database.php");
require_once("course.php");
require_once("usercourses.php");
require_once("adminuser.php");
require_once("notification_class.php");
require_once("user.php");

?>