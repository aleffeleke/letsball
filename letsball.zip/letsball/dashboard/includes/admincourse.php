<?php

class Admincourse extends Db_object  {


   
}
$Admincourse  = new Admincourse ;

?>