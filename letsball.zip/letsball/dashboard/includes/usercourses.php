<?php 
Class usercourses extends Db_object  {

    protected static $dbh_table = "usercourses";
    protected static $db_table_fields = array('title','description','price','images','videolink','useremail');
        

        public $description;
        public $title;
        public $price;
        public $id;
        public $purchasedate;
        public $images;
        public $useremail;
        public $videolink;
        
        public static function find_usercourse_by_id($id){
            global $database;
            $the_result_array =  Self::find_by_query("SELECT * FROM " . Self::$dbh_table .  "  WHERE id = '$id' ");
            return !empty($the_result_array) ? array_shift($the_result_array) : false;
        }
        public static function find_all_usercourse(){
            global $database;
            return  Self::find_by_query("SELECT * FROM " . Self::$dbh_table .  " ");
        }
        public static function find_if_exist_title($title){
            global $database;
            $result_set = $database->query("SELECT * FROM usercourses WHERE title = '$title' ");
            return $result_set->num_rows;
        }
        public static function find_course_by_email($email){
            global $database;
            return  Self::find_by_query("SELECT * FROM usercourses WHERE useremail = '$email' ORDER BY id DESC LIMIT 6 "); 
            

        }
}
$usercourses = new usercourses;
?>