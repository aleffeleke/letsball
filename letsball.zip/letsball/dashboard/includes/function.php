<?php
ob_start();
spl_autoload_register('Myauto');
function Myauto($class){

$class = strtolower($class);

$the_path = $class."php";

if(!file_exists($the_path)){
 return false; 
}
include_once $the_path;
}



function redirect($location){
    header("Location: {$location} ");
     exit;
}


?>