<?php

  Class Users  extends Db_object  {
    protected static $dbh_table = "users";
    protected static $db_table_fields = array('firstname','lastname','password','email','phonenumber','token','Emailconfirm');
    
    public $lastname;
    public $firstname;
    public $Emailconfirm;
    public $token;
    public $oldpassword;
    public $newpassword;
    public $id;
    public $reg_date;
    public $email;
    public $password;
    public $phonenumber;

    public static function login_user($email,$password,$id){
      global $database;
      $email = $database->escape_string($email);
      $password = $database->escape_string($password);
      $id =  $database->escape_string($id);
      $sql = "SELECT * FROM  " . Self::$dbh_table .  "   WHERE email = '$email'";
      $result_set = $database->query($sql);
       if ($result_set->num_rows > 0) {
        // output data of each row
         while($row = $result_set->fetch_assoc()) {

             if(password_verify($password,$row["password"]) and $row["Emailconfirm"] == 1){ 
              $_SESSION['email'] = $email;
              $_SESSION['logid'] = $row['id'];
              $updateuser = "UPDATE users SET loginstatus=1 WHERE id= ".$row['id']." ";
              $database->query($updateuser);
              redirect("index.php?errorid=.$id");
             }
             elseif($row["Emailconfirm"] == 0){
              redirect("?user=made");
             }
             elseif(!password_verify($password,$row["password"]) and $row["Emailconfirm"] == 1){
              redirect("?login=wrong");
             }
             else{
              redirect("?login=wrong");
             }
         }
       } else {
        redirect("?exist=false");
       }
     }
     public function signup_user(){
      $this->password = password_hash($this->password , PASSWORD_DEFAULT);
      $this->token = 'qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNM0123456789!$/()*';
      $this->token = str_shuffle($this->token);
      $this->token = substr($this->token, 0, 10);
      $this->Emailconfirm = 0;
      return empty(Self::find_user_by_email($this->email)) ? $this->create(): redirect('?user=taken');

    }
    public static function admin_login($email,$password){
      global $database;
      $email = $database->escape_string($email);
      $password = $database->escape_string($password);
      $sql = "SELECT * FROM adminlogin  WHERE email = '$email' ";
      $result_set = $database->query($sql);
      if ($result_set->num_rows > 0) {
        while($row = $result_set->fetch_assoc()) {
          if(password_verify($password,$row["password"])){ 
            $_SESSION['adminmail'] = $email;
            redirect("index.php");
          }
          else{
            redirect("?login=wrong");
          }
        }
      }
      else {
        redirect("?exist=false");
      }
    }

    public static function adminpage_numbers($sql){
      global $database;
      $result_set = $database->query($sql);
      return  $result_set->num_rows;
    }
    public static function find_user_online(){
      global $database;
      return Self::find_by_query("SELECT * FROM users WHERE loginstatus=1"); 
           
    }
    public static function find_user_by_id($id){
      global $database;
      $the_result_array =  Self::find_by_query("SELECT * FROM " . Self::$dbh_table .  "  WHERE id = '$id' ");
      return !empty($the_result_array) ? array_shift($the_result_array) : false;
    }
    public static function find_all_users(){
      global $database;
      return  Self::find_by_query("SELECT * FROM  " . Self::$dbh_table .  " ");
    }
  }
  $user = new Users;

  
?>