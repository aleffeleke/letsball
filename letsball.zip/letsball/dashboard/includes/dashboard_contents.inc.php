  <?php   
            //  $find_user = Users::find_user_by_email($_SESSION['email']);
            //  $user = Users::instantation($find_user);
             ?>

 <div class="container">
     <br>
     <br>
     <center>
    <h1>Find your next pickup game</h1>
    <p> Games near you </p>
     </center>
     <?php
        // $full = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        // if(strpos($full , "course=alreadypurchased") == true){
        //   echo "<div style='color:green;'>You already have this course purchased</div>";
        // }
      ?>
           <h3>Sunday October 12 </h3>
     <div class="row" style="margin-top:-30px;">
     <?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "letsballdbh";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM groups";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo '
    <div class="col-lg-4 mt-5">
    <div class="card" style="background:url(https://live.staticflickr.com/8094/8590935046_069be75293_b.jpg); background-size:cover;">
    <div class="card-body pb-0" style="background-color:rgba(0,0,0,0.4);">
    <center>
    <input type="hidden" name="id_indexed" value=2>
  <br>
  <h4 style="color:white; text-transform:uppercase;">' . $row["groupname"]. '</h4>
  <p style="color:white; text-transform:capitalize;"><b style="color:white;">' . $row["groupaddress"]. '</b></p>
  <p style="color:white; text-transform:uppercase;"><b style="color:white;">' . $row["grouptime"]. '</b></p>
  <br>
  <a href="'.$row["groupurl"].'"><button  style="background:linear-gradient(58deg, rgba(220,32,82,1) 35%, rgba(243,60,106,1) 100%);  " class="dash-course-btn">Explore</button></a>  <br>
  <br>
  </center>
  </div>
  </div>
</div>';
    }
} else {
    echo "0 results";
}
$conn->close();
?>
    
        <!-- <?php if(empty($courses)):?>
        <div class="col-lg-4 mt-5">
        <h3>  No course available </h3>
        </div>
        <?php endif ?> -->