<?php
session_start();
require_once('init.php');

   if(isset($_GET['courseid'])){
    $_SESSION['id'] = $_GET['courseid'];
    redirect('../payment.php');
   }
   else{
       redirect('../index.php');
   }
   ?>